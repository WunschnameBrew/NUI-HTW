// static/js/modules/ui.js
import { elements } from './dom.js';
import { state } from './state.js';

export function setLoading(isLoading) {
    state.isLoading = isLoading;
    if(elements.promptInput) elements.promptInput.disabled = isLoading;
    if(elements.sendBtn) elements.sendBtn.disabled = isLoading;
}

export function addMessageToChat(role, text, saveToHistory = true) {
    const div = document.createElement('div');
    div.className = `message ${role === 'user' ? 'user-message' : 'ai-message'}`;
    div.textContent = text;
    elements.chatWindow.appendChild(div);
    elements.chatWindow.scrollTop = elements.chatWindow.scrollHeight;
    
    if (text && saveToHistory) {
        state.chatHistory.push({role: role === 'user' ? 'user' : 'assistant', content: text});
    }
    return div;
}