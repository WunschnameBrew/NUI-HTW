// static/js/modules/dom.js

export const elements = {
    // Containers
    chatWindow: document.getElementById('chat-window'),
    sceneContainer: document.getElementById('scene-container'),
    appContainer: document.getElementById('app-container'),
    settingsPanel: document.getElementById('settings-panel'),
    textInputContainer: document.getElementById('text-input-container'),

    // Inputs
    promptInput: document.getElementById('prompt-input'),
    systemPromptSelect: document.getElementById('system-prompt-select'),
    modelSelect: document.getElementById('model-select'),
    
    // Buttons
    sendBtn: document.getElementById('send-btn'),
    recordButton: document.getElementById('record-btn'),
    settingsBtn: document.getElementById('settings-btn'),
    chatToggleBtn: document.getElementById('chat-toggle-btn'),
    closeSettingsBtn: document.getElementById('close-settings'),
    clearChatBtn: document.getElementById('clear-chat-btn'),
    
    // Toggles
    memoryToggle: document.getElementById('memory-toggle'),
    
    // Visuals
    loadingOverlay: document.getElementById('loading-overlay')
};