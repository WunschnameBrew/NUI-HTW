// static/js/app.js
import { elements } from './modules/dom.js';
import { state } from './modules/state.js';
import { PCMPlayer, setupAudioRecorder, processAudioPacket } from './modules/audio.js';
import * as UI from './modules/ui.js';
import * as Network from './modules/network.js';
import { onWindowResize, startAnimation, loadVRMModel, init3DScene } from './modules/scene.js';

document.addEventListener('DOMContentLoaded', () => {
    init();
});

async function init() {
    // 1. Initial Data Load
    await loadInitData();
    
    // 2. Audio Setup
    setupAudioRecorder(sendAudioToServer);
    
    // 3. Event Listeners
    setupEventListeners();
    
    // 4. Scene Initialization
    window.addEventListener('resize', onWindowResize);
    init3DScene();
    setTimeout(onWindowResize, 100); // Ensure size settles
    startAnimation();
    
    // Remove loading overlay once ready
    if (elements.loadingOverlay) {
        setTimeout(() => elements.loadingOverlay.style.display = 'none', 1000);
    }
}

async function loadInitData() {
    try {
        // Load System Prompts
        const sysData = await Network.fetchSystemPrompts();
        if (elements.systemPromptSelect && sysData.system_prompts) {
            elements.systemPromptSelect.innerHTML = sysData.system_prompts.map(name => 
                `<option value="${name}">${name}</option>`
            ).join('');
        }
        
        // Load Models
        const modelData = await fetch('/get_models').then(res => res.json());
        if (elements.modelSelect && modelData.models) {
            elements.modelSelect.innerHTML = modelData.models.map(name => 
                `<option value="${name}">${name}</option>`
            ).join('');
            
            if (modelData.models.length > 0) {
                loadVRMModel(modelData.models[0]);
            }
        }
    } catch (e) {
        console.error("Init Error", e);
    }
}

function setupEventListeners() {
    // Settings Toggle
    elements.settingsBtn.addEventListener('click', () => {
        elements.settingsPanel.classList.toggle('active');
    });
    
    elements.closeSettingsBtn.addEventListener('click', () => {
        elements.settingsPanel.classList.remove('active');
    });

    // Chat Input Toggle
    elements.chatToggleBtn.addEventListener('click', () => {
        const isHidden = elements.textInputContainer.style.display === 'none';
        elements.textInputContainer.style.display = isHidden ? 'flex' : 'none';
        if (isHidden) elements.promptInput.focus();
    });

    // Send Message
    elements.sendBtn.addEventListener('click', handleChat);
    elements.promptInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !state.isLoading) handleChat();
    });

    // Recording
    elements.recordButton.addEventListener('click', toggleRecording);

    // Settings Changes
    elements.modelSelect.addEventListener('change', (e) => loadVRMModel(e.target.value));
    
    // Clear Chat
    elements.clearChatBtn.addEventListener('click', async () => {
        if (confirm("Clear chat history?")) {
            await Network.postClearHistory();
            elements.chatWindow.innerHTML = '<div class="message ai-message">System Online. Chat Cleared.</div>';
            state.chatHistory = [];
        }
    });
}

async function handleChat() {
    const prompt = elements.promptInput.value.trim();
    if (!prompt || state.isLoading) return;

    elements.promptInput.value = "";
    UI.addMessageToChat('user', prompt);
    UI.setLoading(true);

    try {
        await handleVoiceStream(prompt);
    } catch (error) {
        console.error("Chat Error", error);
    } finally {
        UI.setLoading(false);
    }
}

async function handleVoiceStream(prompt) {
    const payload = {
        prompt: prompt,
        history: state.chatHistory,
        system_prompt_name: elements.systemPromptSelect.value,
        use_memory: elements.memoryToggle.checked
    };

    const aiMessageDiv = UI.addMessageToChat('ai', "");
    
    // Ensure Audio Context is active
    if (state.audioContext.state === 'suspended') await state.audioContext.resume();
    state.audioPlayer = new PCMPlayer(state.audioContext);

    try {
        const response = await Network.postVoiceStream(payload);
        const reader = response.body.getReader();
        const decoder = new TextDecoder("utf-8");
        let buffer = "";
        let fullReply = "";

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop();

            for (const line of lines) {
                if (!line.trim()) continue;
                const packet = JSON.parse(line);
                
                if (packet.type === 'text') {
                    aiMessageDiv.textContent += packet.content;
                    fullReply += packet.content;
                    elements.chatWindow.scrollTop = elements.chatWindow.scrollHeight;
                } else if (packet.type === 'audio') {
                    const float32Data = processAudioPacket(packet);
                    state.audioPlayer.playChunk(float32Data);
                }
            }
        }
        state.chatHistory.push({role: 'assistant', content: fullReply});
    } catch (error) {
        aiMessageDiv.textContent += " [Stream Error]";
    }
}

function toggleRecording() {
    if (state.isRecording) {
        if(state.mediaRecorder) state.mediaRecorder.stop();
        state.isRecording = false;
        elements.recordButton.classList.remove("recording-active");
    } else {
        if (!state.mediaRecorder || state.mediaRecorder.state === 'inactive') {
            setupAudioRecorder(sendAudioToServer);
        }
        setTimeout(() => {
            if (state.mediaRecorder && state.mediaRecorder.state === 'inactive') {
                state.audioChunks = [];
                state.mediaRecorder.start();
                state.isRecording = true;
                elements.recordButton.classList.add("recording-active");
            }
        }, 200);
    }
}

async function sendAudioToServer() {
    const audioBlob = new Blob(state.audioChunks, { type: 'audio/webm' });
    const formData = new FormData();
    formData.append('audio_file', audioBlob, 'recording.webm');
    
    try {
        const data = await Network.postTranscribe(formData);
        if (data.transcription) {
            UI.addMessageToChat('user', data.transcription);
            handleVoiceStream(data.transcription);
        }
    } catch (e) {
        console.error("Transcription Error", e);
    }
}