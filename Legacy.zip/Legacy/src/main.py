# src/main.py
import sys
import asyncio
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

if sys.platform.startswith('win'):
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

from src.config.settings import STATIC_DIR
from src.api.routes import router
from src.services.memory.manager import memory_service
from src.services.llm.bot import llm_manager
from src.services.safety.manager import safety_service 
from src.services.animation.manager import animation_service
from src.services.perception.audio import audio_service

# --- 🛠️ FIX: Add 'utils' to Python Path ---
# This ensures we can import project_manager from root/utils/
root_dir = Path(__file__).resolve().parent.parent
utils_dir = root_dir / "utils"

if str(utils_dir) not in sys.path:
    sys.path.append(str(utils_dir))

try:
    from project_manager import project_manager
    HAS_MANAGER = True
except ImportError as e:
    print(f"⚠️ Warning: project_manager not found in {utils_dir}. Error: {e}")
    HAS_MANAGER = False
# ------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("--- 🚀 AI HUB STARTUP ---")
    
    # 0. Run Project Manager (Auto-Bundle)
    if HAS_MANAGER:
        print("⚙️  Running Project Maintenance (Bundling & Mapping)...")
        # Run in a separate thread to avoid blocking startup
        await asyncio.to_thread(project_manager.run_all)
    
    # 1. Start Memory
    await memory_service.start()
    
    # 2. Start Safety (Explicit Load)
    # We use to_thread to prevent blocking the async loop during the heavy import
    await asyncio.to_thread(safety_service.load_models)
    
    # 4. Check/Convert Animations
    await animation_service.run_startup_scan()
    
    # 5. Start LLM Server
    asyncio.create_task(llm_manager.start_server())
    
    # --- ADD THIS BLOCK ---
    print("🎤 Audio: Initializing Whisper...")
    #await audio_service.start_whisper()
    # ----------------------
    
    yield 
    
    print("--- 🛑 SHUTDOWN ---")
    await memory_service.stop()
    llm_manager.stop_server()
    

app = FastAPI(lifespan=lifespan)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
app.include_router(router)

@app.get("/")
async def root():
    return FileResponse(STATIC_DIR / "../templates/index.html")

if __name__ == "__main__":
    import uvicorn
    # ⚠️ NOTE: reload=True spawns a child process. 
    # The parent imports main.py (lightweight safety).
    # The child imports main.py, runs lifespan, and calls load_models() (Heavy safety, ONCE).
    uvicorn.run("src.main:app", host="0.0.0.0", port=8000, reload=True)