# src/api/routes.py
from fastapi import APIRouter, WebSocket, UploadFile, File, Body, WebSocketDisconnect
from fastapi.responses import StreamingResponse
import json
import asyncio
import glob
import pathlib
import shutil
import os
import base64
import re
from pathlib import Path

# --- IMPORTS ---
from src.api.schemas import ChatRequest, ImageRequest
from src.config.settings import WORKFLOW_DIR, PERSONA_DIR, STATIC_DIR, DATA_DIR, TEMP_DIR
from src.core.engine import thinking_engine
from src.services.llm.bot import llm_manager
from src.services.memory.manager import memory_service
from src.services.execution.runner import execution_service
from src.services.perception.vision import vision_service
from src.services.perception.audio import audio_service
from src.services.image.manager import image_service
from src.services.safety.manager import safety_service

from src.services.image.director import director


router = APIRouter()

# --- 0. STARTUP CLEANUP ---
def cleanup_temp_folder():
    """Wipes the temp folder on startup to ensure a clean slate."""
    if TEMP_DIR.exists():
        for item in TEMP_DIR.iterdir():
            try:
                if item.is_file(): item.unlink()
                elif item.is_dir(): shutil.rmtree(item)
            except Exception as e:
                print(f"Failed to clean temp file {item}: {e}")
                
cleanup_temp_folder() 

# --- 1. UTILITY ENDPOINTS ---

@router.get("/get_workflows")
async def get_workflows():
    if not WORKFLOW_DIR.exists(): return {"workflows": []}
    files = glob.glob(str(WORKFLOW_DIR / "*_workflow.json"))
    return {"workflows": [pathlib.Path(f).stem.replace("_workflow", "") for f in files]}

@router.get("/get_system_prompts")
async def get_system_prompts():
    if not PERSONA_DIR.exists(): return {"system_prompts": []}
    files = glob.glob(str(PERSONA_DIR / "*_Sys.txt"))
    return {"system_prompts": [pathlib.Path(f).stem.replace("_Sys", "") for f in files]}

@router.get("/get_models")
async def get_models():
    assets_dir = STATIC_DIR / "assets"
    if not assets_dir.exists(): return {"models": []}
    files = glob.glob(str(assets_dir / "*.vrm"))
    return {"models": [pathlib.Path(f).name for f in files]}

@router.post("/sync_history")
async def sync_history(payload: dict = Body(...)):
    return {"status": "synced"}


@router.get("/health")
async def health():
    return {"status": "ok", "llm": llm_manager.is_active}


# --- 2. CHAT & THINKING ---

@router.post("/chat")
async def chat_endpoint(req: ChatRequest):
    # --- INTERCEPTOR ---
    if req.prompt.lower().startswith("chapter:"):
        return StreamingResponse(iter(["Please use the Studio tab for Manga generation."]), media_type="text/plain")
    
    # Aggressively unload image models if we are chatting
    if not llm_manager.is_active:
        await image_service.unload()
    
    if req.safe_mode and not safety_service.is_safe(req.prompt):
        return StreamingResponse(iter(["I cannot answer that."]), media_type="text/plain")

    if req.style == "thinking":
        return StreamingResponse(
            thinking_engine.run_thunderdome(req.prompt, req.history),
            media_type="text/plain"
        )
    
    vision_context = ""
    if "look at this" in req.prompt.lower() or "what is on my screen" in req.prompt.lower():
        b64 = vision_service.take_screenshot()
        if b64:
            vision_context = " [System: Screenshot Attached]"
            
    system_instruction = "You are a helpful AI."
    if req.system_prompt_name and req.system_prompt_name != "Default":
        sys_path = PERSONA_DIR / f"{req.system_prompt_name}_Sys.txt"
        if sys_path.exists():
            system_instruction = sys_path.read_text(encoding="utf-8")

    async def generator():
        messages = [{"role": "system", "content": system_instruction}]
        for m in req.history: messages.append(m)
        
        if req.use_memory:
            docs = await memory_service.search_all(req.prompt)
            if docs: messages[-1]['content'] += f"\nCONTEXT: {docs}"

        messages.append({"role": "user", "content": req.prompt + vision_context})
        
        full_resp = ""
        async for token in llm_manager.stream_chat(
            messages, 
            temperature=0.7, 
            repeat_penalty=1.05,
            frequency_penalty=0.02,
            presence_penalty=0.02
        ):
            full_resp += token
            yield token
        
        if req.use_memory:
            await memory_service.save_interaction(req.prompt, full_resp)

    return StreamingResponse(generator(), media_type="text/plain")


# --- 3. TOOLS & MEDIA ---

@router.post("/generate_image")
async def gen_image(req: dict = Body(...)): 
    llm_manager.hibernate() 
    workflow_name = req.get("workflow", "juggernaut-sfw")
    return await image_service.generate(req, workflow_name)

@router.post("/transcribe")
async def transcribe(audio_file: UploadFile = File(...)):
    content = await audio_file.read()
    text = await audio_service.transcribe(content)
    return {"transcription": text}

@router.post("/synthesize_speech")
async def synthesize(payload: dict = Body(...)):
    text = payload.get("text", "")
    return await audio_service.synthesize(text)

@router.websocket("/thinking/ws")
async def thinking_ws(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_json()
            if data['type'] == 'start_task':
                if not llm_manager.is_active:
                    await image_service.unload()
                
                async for chunk in thinking_engine.run_thunderdome(data['prompt'], data['history']):
                    await websocket.send_json({"type": "stream_chunk", "content": chunk})
                await websocket.send_json({"type": "status", "status": "finished"})
    except: pass
    
# --- 4. INGESTION ---

@router.post("/ingest_knowledge")
async def ingest():
    input_dir = DATA_DIR / "knowledge_input"
    processed_dir = DATA_DIR / "knowledge_processed"
    input_dir.mkdir(exist_ok=True)
    processed_dir.mkdir(exist_ok=True)
    
    projects = [d for d in input_dir.iterdir() if d.is_dir()]
    if not projects:
        return {"status": "No project folders found in knowledge_input", "processed": []}

    status_log = []

    for project_dir in projects:
        project_name = project_dir.name
        file_map = {}
        files_to_process = []
        
        async def scan_folder_async(path, structure_dict):
            for item in os.scandir(path):
                if len(files_to_process) % 50 == 0: await asyncio.sleep(0)

                if item.is_dir():
                    structure_dict[item.name] = {}
                    await scan_folder_async(Path(item.path), structure_dict[item.name])
                    if not structure_dict[item.name]: del structure_dict[item.name]

                elif item.is_file():
                    if Path(item.name).suffix.lower() in ['.txt', '.md', '.json', '.py', '.js', '.html', '.css', '.xml', '.yml', '.cpp', '.h', '.c', '.hpp']:
                        structure_dict[item.name] = "__FILE__"
                        files_to_process.append(Path(item.path))

        await scan_folder_async(project_dir, file_map)
        project_id = await memory_service.create_or_update_project(project_name, file_map)
        
        for i, file_path in enumerate(files_to_process):
            if i % 10 == 0: await asyncio.sleep(0)
            try:
                text = file_path.read_text(encoding='utf-8', errors='ignore')
                rel_source = str(file_path.relative_to(project_dir)).replace("\\", "/")
                await memory_service.ingest_file_smart(project_id, rel_source, text)
            except Exception as e:
                print(f"⚠️ Error reading {file_path.name}: {e}")

        dest_path = processed_dir / project_name
        counter = 1
        while dest_path.exists():
            dest_path = processed_dir / f"{project_name}_{counter}"
            counter += 1
        try:
            shutil.move(str(project_dir), str(dest_path))
        except Exception as e:
            print(f"Error moving folder: {e}")

        status_log.append({"project": project_name, "files_ingested": len(files_to_process)})

    return {"status": "completed", "details": status_log}
    
@router.post("/chat_voice_stream")
async def chat_voice_stream_endpoint(req: ChatRequest):
    if not llm_manager.is_active:
        await image_service.unload()

    system_instruction = "You are a helpful AI."
    if req.system_prompt_name and req.system_prompt_name != "Default":
        sys_path = PERSONA_DIR / f"{req.system_prompt_name}_Sys.txt"
        if sys_path.exists():
            system_instruction = sys_path.read_text(encoding="utf-8")

    async def response_generator():
        messages = [{"role": "system", "content": system_instruction}]
        messages.extend(req.history)
        
        if req.use_memory:
            docs = await memory_service.search_all(req.prompt)
            if docs: messages[-1]['content'] += f"\nCONTEXT: {docs}"

        messages.append({"role": "user", "content": req.prompt})

        text_buffer = ""
        sentence_end_regex = re.compile(r'(?<=[.!?])\s+')
        full_resp = ""

        async for token in llm_manager.stream_chat(
            messages, 
            temperature=0.7, 
            repeat_penalty=1.15,
            frequency_penalty=0.02, 
            presence_penalty=0.02
        ):
            full_resp += token
            yield json.dumps({"type": "text", "content": token}) + "\n"
            
            text_buffer += token
            parts = sentence_end_regex.split(text_buffer)
            
            if len(parts) > 1:
                sentence_to_speak = parts[0].strip()
                text_buffer = " ".join(parts[1:])
                
                if sentence_to_speak:
                    tts_response = await audio_service.synthesize(sentence_to_speak)
                    async for audio_chunk in tts_response.body_iterator:
                        b64_audio = base64.b64encode(audio_chunk).decode('utf-8')
                        yield json.dumps({"type": "audio", "data": b64_audio}) + "\n"

        if text_buffer.strip():
            tts_response = await audio_service.synthesize(text_buffer.strip())
            async for audio_chunk in tts_response.body_iterator:
                b64_audio = base64.b64encode(audio_chunk).decode('utf-8')
                yield json.dumps({"type": "audio", "data": b64_audio}) + "\n"
        
        if req.use_memory:
            await memory_service.save_interaction(req.prompt, full_resp)

    return StreamingResponse(response_generator(), media_type="application/x-ndjson")
    
# --- 5. STUDIO ---

@router.websocket("/studio/ws")
async def studio_ws(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_json()
            await director.handle_ws_message(websocket, data)
    except WebSocketDisconnect:
        await director.cleanup_session(websocket)
        print("Studio WS disconnected")
    except Exception as e:
        print(f"Studio WS Error: {e}")
        await director.cleanup_session(websocket)