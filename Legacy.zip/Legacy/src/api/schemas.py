# src/api/schemas.py
from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    prompt: str
    history: List[Dict[str, str]] = []
    system_prompt_name: str = "Default"
    use_memory: bool = False
    style: str = "karaoke" # 'thinking', 'karaoke', 'text'
    safe_mode: bool = True
    image: Optional[str] = None # Base64

class ImageRequest(BaseModel):
    prompt: str
    workflow: str

class IngestResponse(BaseModel):
    status: str
    processed: int
    errors: int