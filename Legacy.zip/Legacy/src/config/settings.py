# src/config/settings.py
import os
import pathlib
import urllib.parse

# --- CORE PATHS ---
APP_DIR = pathlib.Path(__file__).parent.parent.resolve() # src/
ROOT_DIR = APP_DIR.parent.resolve() # project root/

DATA_DIR = ROOT_DIR / "data"
STATIC_DIR = ROOT_DIR / "static"
MODELS_DIR = ROOT_DIR / "Llama_Models"
WORKFLOW_DIR = ROOT_DIR / "Workflows"
PERSONA_DIR = ROOT_DIR / "Persona"
TEMP_DIR = DATA_DIR / "temp" # <--- NEW

# Ensure dirs exist
for p in [DATA_DIR, MODELS_DIR, WORKFLOW_DIR, PERSONA_DIR]:
    p.mkdir(parents=True, exist_ok=True)

# --- DATABASE ---
RAW_PASSWORD = r'''^grE01$Q10!d47a?"'''
ENCODED_PASS = urllib.parse.quote_plus(RAW_PASSWORD)
DB_URL = f"postgresql://postgres:{ENCODED_PASS}@127.0.0.1:5432/ai_hub_db"

# --- LLM SETTINGS ---
LLM_API_URL = "http://127.0.0.1:8001/v1"
LLAMA_EXE = ROOT_DIR / "Llama.cpp" / "llama-server.exe"

# Auto-detect Model
DEFAULT_MODEL = ""
candidates = list(MODELS_DIR.glob("*.gguf"))
if candidates:
    DEFAULT_MODEL = str(candidates[0])

# --- AUDIO TOOLS (WHISPER & PIPER) ---
WHISPER_DIR = ROOT_DIR / "Whisper"
# Auto-detect Whisper executable
POSSIBLE_EXES = ["server.exe", "whisper-server.exe", "main.exe"]
WHISPER_EXE = None
for exe in POSSIBLE_EXES:
    if (WHISPER_DIR / exe).exists():
        WHISPER_EXE = WHISPER_DIR / exe
        break
# Fallback
if not WHISPER_EXE:
    WHISPER_EXE = WHISPER_DIR / "server.exe"

PIPER_DIR = ROOT_DIR / "Piper"
PIPER_EXE = PIPER_DIR / "piper.exe"
PIPER_VOICE = PIPER_DIR / "en_US-amy-medium.onnx"