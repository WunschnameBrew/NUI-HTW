# src/services/perception/audio.py
import asyncio
import subprocess
import os
import uuid
import httpx
import logging
import sys
import shutil
from pathlib import Path
from fastapi.responses import StreamingResponse
from src.config.settings import DATA_DIR, WHISPER_DIR

# --- LOGGING SETUP ---
logger = logging.getLogger("AUDIO")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter('%(asctime)s [AUDIO] %(message)s'))
    logger.addHandler(handler)

# --- PATHS ---
CURRENT_FILE = Path(__file__).resolve()
PROJECT_ROOT = CURRENT_FILE.parents[3] 

# 1. FIX: Try local FFmpeg first, fallback to System FFmpeg
LOCAL_FFMPEG = PROJECT_ROOT / "Tools" / "ffmpeg.exe"
SYSTEM_FFMPEG = shutil.which("ffmpeg")

if LOCAL_FFMPEG.exists():
    FFMPEG_EXE = str(LOCAL_FFMPEG)
    logger.info(f"✅ Audio: Using Local FFmpeg at {FFMPEG_EXE}")
elif SYSTEM_FFMPEG:
    FFMPEG_EXE = SYSTEM_FFMPEG
    logger.info(f"⚠️ Audio: Local FFmpeg missing. Using System FFmpeg at {FFMPEG_EXE}")
else:
    logger.critical("❌ Audio: FFmpeg NOT FOUND anywhere.")
    FFMPEG_EXE = None

WHISPER_EXE = PROJECT_ROOT / "Whisper" / "whisper-server.exe"
WHISPER_MODEL = PROJECT_ROOT / "Whisper" / "models" / "ggml-medium-q5_0.bin"

PIPER_EXE = PROJECT_ROOT / "Piper" / "piper.exe"
PIPER_VOICE = PROJECT_ROOT / "Piper" / "en_US-amy-medium.onnx" 

TEMP_DIR = DATA_DIR / "temp"
TEMP_DIR.mkdir(parents=True, exist_ok=True)

# 2. FIX: Restore the Filter List
HALLUCINATIONS = [
    "[BLANK_AUDIO]", "[INAUDIBLE]", "[SILENCE]", "[MUSIC]", "[NOISE]"
]

class AudioService:
    def __init__(self):
        self.whisper_proc = None
        self.port = 8003
        self.run_diagnostics()

    def run_diagnostics(self):
        logger.info("--- 🏥 AUDIO DIAGNOSTIC ---")
        if not FFMPEG_EXE: logger.critical("❌ FFMPEG MISSING entirely.")
        if not WHISPER_EXE.exists(): logger.critical(f"❌ WHISPER MISSING: {WHISPER_EXE}")
        if not PIPER_EXE.exists(): logger.error(f"❌ PIPER EXE MISSING: {PIPER_EXE}")

    def _run_subprocess_sync(self, cmd):
        try:
            # Hide the console window on Windows
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            
            result = subprocess.run(
                cmd, 
                capture_output=True, 
                text=True, 
                check=True,
                startupinfo=startupinfo
            )
            return True, result.stdout
        except subprocess.CalledProcessError as e:
            return False, e.stderr
        except Exception as e:
            return False, str(e)

    async def start_whisper(self):
        if self.whisper_proc and self.whisper_proc.poll() is None: return 
        if not WHISPER_EXE.exists(): return

        cmd = [str(WHISPER_EXE), "-m", str(WHISPER_MODEL), "--port", str(self.port), "--threads", "4"]
        try:
            self.whisper_proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            await asyncio.sleep(2)
        except Exception as e:
            logger.error(f"❌ Whisper Launch Error: {e}")

    async def transcribe(self, audio_bytes: bytes) -> str:
        if not FFMPEG_EXE: return ""
        
        try:
            await self.start_whisper()
            file_id = uuid.uuid4()
            input_path = TEMP_DIR / f"{file_id}.webm"
            wav_path = TEMP_DIR / f"{file_id}.wav"
            
            with open(input_path, "wb") as f: f.write(audio_bytes)

            # Convert to WAV 16k Mono
            cmd = [FFMPEG_EXE, "-y", "-i", str(input_path), "-ar", "16000", "-ac", "1", "-c:a", "pcm_s16le", str(wav_path)]
            success, error_msg = await asyncio.to_thread(self._run_subprocess_sync, cmd)
            
            if not success:
                logger.error(f"❌ FFMPEG Failed: {error_msg}")
                return ""

            async with httpx.AsyncClient(timeout=30.0) as client:
                with open(wav_path, "rb") as f:
                    resp = await client.post(
                        f"http://127.0.0.1:{self.port}/inference", 
                        files={"file": f}, 
                        data={"response_format": "json"}
                    )
                    text = resp.json().get("text", "").strip()

                    # 3. FIX: Check for Hallucinations
                    for bad_word in HALLUCINATIONS:
                        if bad_word in text.upper():
                            logger.warning(f"🔇 Filtered Hallucination: '{text}'")
                            return ""
                    
                    logger.info(f"🗣️ Heard: '{text}'")
                    return text

        except Exception as e:
            logger.critical(f"❌ Transcription Error: {e}")
            return ""
        finally:
            # Cleanup
            if 'input_path' in locals() and input_path.exists(): 
                try: os.remove(input_path)
                except: pass
            if 'wav_path' in locals() and wav_path.exists(): 
                try: os.remove(wav_path)
                except: pass

    def _piper_generator(self, text: str):
        try:
            proc = subprocess.Popen(
                [str(PIPER_EXE), "-m", str(PIPER_VOICE), "--output-raw"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            proc.stdin.write(text.encode('utf-8'))
            proc.stdin.close()
            while True:
                chunk = proc.stdout.read(4096)
                if not chunk: break
                yield chunk
            proc.wait()
        except Exception as e:
            logger.error(f"❌ Piper Stream Crash: {e}")

    async def synthesize(self, text: str):
        if not PIPER_EXE.exists(): 
            return StreamingResponse(iter([b""]), media_type="audio/wav")
        return StreamingResponse(self._piper_generator(text), media_type="audio/wav")

audio_service = AudioService()