# src/services/perception/vision.py
import mss
import base64
import io
from PIL import Image

class VisionService:
    def __init__(self):
        self.sct = mss.mss()

    def take_screenshot(self, monitor_idx=1):
        """Captures screen and returns optimized Base64 JPEG."""
        try:
            # Validate monitor index
            if monitor_idx > len(self.sct.monitors) - 1:
                monitor_idx = 1

            sct_img = self.sct.grab(self.sct.monitors[monitor_idx])
            
            # Convert to PIL
            img = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")
            
            # Smart Resize (Max 1280px to save tokens/bandwidth)
            max_dim = 1280
            width, height = img.size
            if width > max_dim or height > max_dim:
                ratio = min(max_dim / width, max_dim / height)
                img = img.resize((int(width * ratio), int(height * ratio)), Image.Resampling.LANCZOS)

            # Export to JPEG (smaller than PNG)
            buffer = io.BytesIO()
            img.save(buffer, format="JPEG", quality=85)
            return base64.b64encode(buffer.getvalue()).decode('utf-8')

        except Exception as e:
            print(f"❌ Vision Error: {e}")
            return None

vision_service = VisionService()