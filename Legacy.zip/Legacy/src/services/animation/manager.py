# src/services/animation/manager.py
# ==============================================================================
# ANIMATION PIPELINE CREDITS
# Logic adapted from: https://github.com/tk256ailab/fbx2vrma-converter
# Special thanks to tk256ailab for the VRMC_vrm_animation metadata structure.
# ==============================================================================

import os
import subprocess
import asyncio
import json
import shutil
from pathlib import Path
from src.config.settings import STATIC_DIR, ROOT_DIR

# --- CONFIG ---
TOOLS_DIR = ROOT_DIR / "Tools"
CONVERTER_EXE = TOOLS_DIR / "fbx2gltf.exe"

ANIMATION_ROOT = STATIC_DIR / "assets" / "animations"
RAW_DIR = ANIMATION_ROOT / "raw_fbx"
CONVERTED_DIR = ANIMATION_ROOT / "converted_gltf"

# MIXAMO -> VRM BONE MAP
BONE_MAP = {
    'mixamorig:Hips': 'hips', 'mixamorig:Spine': 'spine', 'mixamorig:Spine1': 'chest',
    'mixamorig:Spine2': 'upperChest', 'mixamorig:Neck': 'neck', 'mixamorig:Head': 'head',
    'mixamorig:LeftShoulder': 'leftShoulder', 'mixamorig:LeftArm': 'leftUpperArm',
    'mixamorig:LeftForeArm': 'leftLowerArm', 'mixamorig:LeftHand': 'leftHand',
    'mixamorig:RightShoulder': 'rightShoulder', 'mixamorig:RightArm': 'rightUpperArm',
    'mixamorig:RightForeArm': 'rightLowerArm', 'mixamorig:RightHand': 'rightHand',
    'mixamorig:LeftUpLeg': 'leftUpperLeg', 'mixamorig:LeftLeg': 'leftLowerLeg',
    'mixamorig:LeftFoot': 'leftFoot', 'mixamorig:LeftToeBase': 'leftToes',
    'mixamorig:RightUpLeg': 'rightUpperLeg', 'mixamorig:RightLeg': 'rightLowerLeg',
    'mixamorig:RightFoot': 'rightFoot', 'mixamorig:RightToeBase': 'rightToes'
}
BONE_MAP_SIMPLE = {k.split(":")[1]: v for k, v in BONE_MAP.items()}

class AnimationService:
    def __init__(self):
        RAW_DIR.mkdir(parents=True, exist_ok=True)
        CONVERTED_DIR.mkdir(parents=True, exist_ok=True)

    async def run_startup_scan(self):
        if not CONVERTER_EXE.exists():
            print(f"⚠️ Animation: fbx2gltf.exe not found in {TOOLS_DIR}.")
            return

        print("🏃 Animation: Scanning for FBX files...")
        
        tasks = []
        for fbx_file in RAW_DIR.glob("*.fbx"):
            target_file = CONVERTED_DIR / f"{fbx_file.stem}.vrma"
            
            # Re-convert if missing OR if source is newer
            if not target_file.exists() or fbx_file.stat().st_mtime > target_file.stat().st_mtime:
                print(f"   ⚙️  Converting: {fbx_file.name} -> .vrma (Embedded)")
                tasks.append(self._convert_to_vrma(fbx_file, target_file))
        
        if tasks:
            await asyncio.gather(*tasks)
            print(f"✅ Animation: Processed {len(tasks)} files.")
        
        self._generate_index()

    async def _convert_to_vrma(self, input_path: Path, output_path: Path):
        """
        Runs fbx2gltf with --embed to generate a single JSON file, then injects metadata.
        """
        temp_gltf = output_path.with_suffix(".temp.gltf")
        
        # USE --embed TO AVOID SEPARATE BIN FILES
        cmd = [
            str(CONVERTER_EXE),
            "--embed",           # <--- CRITICAL FIX: Embeds binary in JSON
            "--input", str(input_path),
            "--output", str(temp_gltf)
        ]
        
        try:
            await asyncio.to_thread(subprocess.run, cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            if temp_gltf.exists():
                # Inject Metadata
                self._inject_vrma_metadata(temp_gltf)
                
                # Move to final .vrma filename
                if output_path.exists():
                    os.remove(output_path)
                shutil.move(str(temp_gltf), str(output_path))
                
        except Exception as e:
            print(f"❌ VRMA Conversion Error ({input_path.name}): {e}")
        finally:
            if temp_gltf.exists(): os.remove(temp_gltf)

    def _inject_vrma_metadata(self, gltf_path: Path):
        try:
            with open(gltf_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            human_bones = {}
            nodes = data.get("nodes", [])
            
            for idx, node in enumerate(nodes):
                name = node.get("name", "")
                clean_name = name.split(":")[-1]
                vrm_bone = BONE_MAP.get(name) or BONE_MAP.get(f"mixamorig:{name}") or BONE_MAP_SIMPLE.get(clean_name)
                
                if vrm_bone:
                    human_bones[vrm_bone] = {"node": idx}

            max_duration = 0
            if "accessors" in data:
                for acc in data["accessors"]:
                    if acc.get("max") and len(acc["max"]) > 0:
                         val = acc["max"][0]
                         if val > max_duration: max_duration = val

            extension_data = {
                "specVersion": "1.0",
                "humanoid": {"humanBones": human_bones},
                "meta": {"duration": max_duration}
            }

            if "extensions" not in data: data["extensions"] = {}
            data["extensions"]["VRMC_vrm_animation"] = extension_data
            
            if "extensionsUsed" not in data: data["extensionsUsed"] = []
            if "VRMC_vrm_animation" not in data["extensionsUsed"]:
                data["extensionsUsed"].append("VRMC_vrm_animation")

            with open(gltf_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)

        except Exception as e:
            print(f"   ⚠️ Metadata Injection Failed: {e}")

    def _generate_index(self):
        index_path = ANIMATION_ROOT / "index.md"
        lines = []
        groups = {"neutral": [], "happy": [], "angry": [], "sad": [], "taunt": []}
        
        for f in CONVERTED_DIR.glob("*.vrma"):
            name_lower = f.stem.lower()
            assigned = False
            for cat in groups:
                if cat in name_lower:
                    groups[cat].append(f.name)
                    assigned = True
                    break
            if not assigned:
                groups["neutral"].append(f.name)

        for cat, files in groups.items():
            if not files: continue
            lines.append(f"#{cat}")
            for fname in files:
                lines.append(f"- {fname} 1.0")
            lines.append("")

        index_path.write_text("\n".join(lines), encoding="utf-8")
        print("📝 Animation: Index updated.")

animation_service = AnimationService()