# src/services/llm/bot.py
import asyncio
import subprocess
import os
import httpx
from openai import AsyncOpenAI
from src.config.settings import LLM_API_URL, LLAMA_EXE, DEFAULT_MODEL, ROOT_DIR

class LLMService:
    def __init__(self):
        self.process = None
        self.lock = asyncio.Lock()
        self.client = AsyncOpenAI(base_url=LLM_API_URL, api_key="sk-local")
        self.is_active = False

    async def start_server(self):
        """Launches llama-server.exe."""
        async with self.lock:
            # If already running, just return. Do not restart.
            if self.is_running(): 
                print("🧠 LLM: Already running.")
                return

            if not os.path.exists(DEFAULT_MODEL):
                print(f"❌ LLM: Model not found at {DEFAULT_MODEL}")
                return

            print("🧠 LLM: Waking up (Loading into VRAM)...")
            
            cmd = [
                str(LLAMA_EXE),
                "--model", DEFAULT_MODEL,
                # --- OPTIMIZATION FOR 7GB SETUP ---
                # 80k context is risky on 12GB if SDXL is active. 
                # 32k is safer, but if you want 80k, keep 81920.
                # If you crash, lower this to 32768.
                "--ctx-size", "102400",       
                "--n-gpu-layers", "-1",      
                "--batch-size", "256",       # Lower batch size to save VRAM during processing
                "--port", "8001",
                "--flash-attn", "on",        
                "--cache-reuse", "256",      
                "--parallel", "1",           
                # KV Cache Quantization is MANDATORY for 80k context on 12GB
                "--cache-type-k", "q4_0",    # q8_0 is higher quality, q4_0 saves more VRAM. Try q8 first.
                "--cache-type-v", "q4_0"
            ]
            
            jinja_path = ROOT_DIR / "templates" / "gemma_custom.jinja"
            
            if jinja_path.exists():
                print(f"🧠 LLM: Using custom template: {jinja_path.name}")
                cmd.extend(["--chat-template-file", str(jinja_path)])
            
            self.process = subprocess.Popen(
                cmd, 
                stdout=subprocess.DEVNULL, 
                stderr=subprocess.DEVNULL
            )
            
            # Health check loop
            for _ in range(60): # Give it 30s to load
                await asyncio.sleep(0.5)
                try:
                    async with httpx.AsyncClient() as http:
                        resp = await http.get(f"http://127.0.0.1:8001/health")
                        if resp.status_code == 200:
                            self.is_active = True
                            print("✅ LLM: Ready & Resident in VRAM.")
                            return
                except: pass
            
            print("❌ LLM: Failed to start.")

    def stop_server(self):
        """Actually kills the process. Only used on app exit."""
        if self.process:
            print("💤 LLM: Shutting down (App Exit)...")
            self.process.terminate()
            self.process = None
            self.is_active = False

    def hibernate(self):
        """
        DISABLED for Simultaneous Mode.
        The image generation route usually calls this. We ignore it now.
        """
        print("🛡️ LLM: Hibernation requested but ignored (Simultaneous Mode Active).")
        pass 

    def is_running(self):
        return self.process and self.process.poll() is None

    async def stream_chat(self, messages, grammar=None, temperature=0.7, **kwargs):
        if not self.is_active: await self.start_server()

        # --- UPDATE THIS SECTION ---
        extra_body = {
            "cache_prompt": True,
            # 1. Define the Sampler Order (DRY must run before others)
            "samplers": ["dry", "top_k", "top_p", "min_p", "temperature"],
            
            # 2. DRY Sampling (Fixes 4B repetition/loops)
            "dry_multiplier": 0.8,
            "dry_base": 1.75,
            "dry_allowed_length": 2,
            "dry_penalty_last_n": -1,
            
            # 3. Min-P (Replaces Top-P for smarter choices)
            "min_p": 0.05,
            "repeat_penalty": 1.1
        }
        # ---------------------------

        if grammar: extra_body["grammar"] = grammar
        
        # Keep existing kwargs logic if you want overrides
        if "repeat_penalty" in kwargs:
             extra_body["repeat_penalty"] = kwargs["repeat_penalty"]

        try:
            stream = await self.client.chat.completions.create(
                model="custom-model",
                messages=messages,
                temperature=temperature,
                stream=True,
                extra_body=extra_body,
                # Set standard penalties to 0 because DRY/Min-P handles it better now
                frequency_penalty=kwargs.get("frequency_penalty", 0.0),
                presence_penalty=kwargs.get("presence_penalty", 0.0),
                stop=kwargs.get("stop", [])
            )
            async for chunk in stream:
                if chunk.choices[0].delta.content:
                    yield chunk.choices[0].delta.content
        except Exception as e:
            yield f"[LLM Error: {e}]"

llm_manager = LLMService()