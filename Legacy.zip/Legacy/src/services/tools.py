# src/services/tools.py
import asyncio
from ddgs import DDGS
from src.services.memory.manager import memory_service

class ToolService:
    def __init__(self):
        self.ddgs = DDGS()

    def search_sync(self, query: str, max_results: int = 5):
        """DuckDuckGo Search (Blocking)"""
        try:
            results = list(self.ddgs.text(
                query, 
                region='us-en', 
                safesearch='off', 
                timelimit='y',
                max_results=max_results
            ))
            return results
        except Exception as e:
            print(f"❌ Search Error: {e}")
            return []

    async def web_search(self, query: str):
        """Async wrapper for Web Search."""
        print(f"🌐 Tools: Searching '{query}'...")
        results = await asyncio.to_thread(self.search_sync, query)
        
        if not results: return "[System: No results found.]"
        
        text = "--- WEB SEARCH RESULTS ---\n"
        for i, res in enumerate(results, 1):
            text += f"{i}. [{res.get('title')}]({res.get('href')})\n   {res.get('body')}\n\n"
        return text

    async def read_file(self, filename: str):
        """
        Uses the Memory Service to find file content by name.
        """
        # This is a basic implementation. In a real app, you might want direct file access.
        # For now, we search the vector DB for the filename.
        docs = await memory_service.search_all(f"filename: {filename}", limit=1)
        if docs:
            return f"--- FILE CONTENT ({filename}) ---\n{docs[0]}\n"
        return f"[System: File '{filename}' not found in knowledge base.]"

tools_service = ToolService()