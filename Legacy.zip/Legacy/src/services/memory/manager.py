# src/services/memory/manager.py
import asyncpg
import asyncio
import json
from typing import List, Dict, Optional
from pgvector.asyncpg import register_vector
from src.config.settings import DB_URL

try:
    from sentence_transformers import SentenceTransformer
except ImportError:
    SentenceTransformer = None

# --- HELPERS: SPLITTING & MATH ---

def calculate_overlap(prev_chunk: str, current_chunk: str, max_check: int = 200) -> int:
    """
    Mathematically determines the exact overlap integer between two text blocks.
    Crucial for lossless reconstruction.
    """
    if not prev_chunk: return 0
    # Optimization: We only check the tail of prev against the head of current
    check_len = min(len(prev_chunk), len(current_chunk), max_check)
    
    for i in range(check_len, 0, -1):
        if prev_chunk.endswith(current_chunk[:i]):
            return i
    return 0

def recursive_split_text(text: str, chunk_size=1000, chunk_overlap=150) -> List[str]:
    """
    Standalone Recursive Character Splitter.
    Prioritizes semantic boundaries: Paragraphs -> Lines -> Sentences.
    """
    separators = ["\n\n", "\n", " ", ""]
    
    def _split(text, separators):
        final_chunks = []
        separator = separators[-1]
        new_separators = []
        
        # Find the best separator that exists in the text
        for i, sep in enumerate(separators):
            if sep == "":
                separator = ""
                break
            if sep in text:
                separator = sep
                new_separators = separators[i+1:]
                break
        
        # Split
        splits = text.split(separator) if separator else list(text)
        good_splits = []
        
        # Merge small splits back together to fill chunk_size
        current_chunk = ""
        for s in splits:
            # Re-attach separator unless it's the empty string
            s_with_sep = s + separator if separator else s
            
            if len(current_chunk) + len(s_with_sep) < chunk_size:
                current_chunk += s_with_sep
            else:
                if current_chunk:
                    good_splits.append(current_chunk)
                current_chunk = s_with_sep
        if current_chunk:
            good_splits.append(current_chunk)
            
        # Recurse if any chunk is still too big
        for chunk in good_splits:
            if len(chunk) > chunk_size:
                if new_separators:
                    final_chunks.extend(_split(chunk, new_separators))
                else:
                    # Hard truncate if we are at char level (rare fallback)
                    final_chunks.append(chunk[:chunk_size])
            else:
                final_chunks.append(chunk)
                
        return final_chunks

    # Post-process to ensure we strictly have chunks.
    # Note: This basic recursion splits well but doesn't force overlap. 
    # For a perfect RAG, we apply a sliding window on the result if needed,
    # OR we rely on the fact that 'calculate_overlap' handles whatever structure we get.
    # For this implementation, we rely on the natural semantic structure 
    # but strictly measure the seams.
    return _split(text, separators)

class MemoryService:
    def __init__(self):
        self.pool = None
        self.model = None 
        
    async def list_project_files(self, project_name: str) -> List[str]:
        """
        Returns a list of ALL distinct filenames associated with a project.
        Used for 'ITERATE' / Audit modes.
        """
        if not self.pool: return []
        
        async with self.pool.acquire() as conn:
            # Get project ID
            pid_row = await conn.fetchrow("SELECT id FROM projects WHERE name = $1", project_name)
            if not pid_row: return []
            project_id = pid_row['id']
            
            # Get all distinct sources
            rows = await conn.fetch("""
                SELECT DISTINCT source 
                FROM knowledge 
                WHERE project_id = $1 
                ORDER BY source ASC
            """, project_id)
            
            return [r['source'] for r in rows]
        
    async def _init_connection(self, conn):
        try:
            # 1. Enable Vector Search & Trigram
            await conn.execute("CREATE EXTENSION IF NOT EXISTS vector;")
            await conn.execute("CREATE EXTENSION IF NOT EXISTS pg_trgm;")
            await register_vector(conn)
        except Exception as e:
            print(f"⚠️ DB Init Warning: {e}")

    async def start(self):
        print("💾 Memory: Connecting to Database...")
        try:
            # Load model on CPU
            if SentenceTransformer:
                self.model = await asyncio.to_thread(
                    SentenceTransformer, 'all-MiniLM-L6-v2', device='cpu'
                )
            
            self.pool = await asyncpg.create_pool(
                dsn=DB_URL, min_size=5, max_size=20, init=self._init_connection
            )
            
            # --- SCHEMA SETUP ---
            async with self.pool.acquire() as conn:
                # 1. Projects Table
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS projects (
                        id SERIAL PRIMARY KEY,
                        name TEXT UNIQUE NOT NULL,
                        file_structure JSONB, 
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)

                # 2. Knowledge Table (Updated V2 Schema)
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS knowledge (
                        id SERIAL PRIMARY KEY,
                        project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
                        content TEXT,
                        source TEXT,
                        embedding vector(384),
                        ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                
                # --- V2 MIGRATION (Idempotent) ---
                # Add columns if they don't exist
                await conn.execute("ALTER TABLE knowledge ADD COLUMN IF NOT EXISTS chunk_index INTEGER DEFAULT 0;")
                await conn.execute("ALTER TABLE knowledge ADD COLUMN IF NOT EXISTS overlap_size INTEGER DEFAULT 0;")

                # 3. Memories Table
                await conn.execute("""
                    CREATE TABLE IF NOT EXISTS memories (
                        id SERIAL PRIMARY KEY,
                        content TEXT,
                        embedding vector(384),
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
                
                # --- INDEXES ---
                await conn.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_source_trgm ON knowledge USING gin (source gin_trgm_ops);")
                await conn.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_embedding ON knowledge USING hnsw (embedding vector_cosine_ops);")
                await conn.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_project_id ON knowledge (project_id);")
                # New V2 Index for Ordered Retrieval
                await conn.execute("CREATE INDEX IF NOT EXISTS idx_knowledge_source_order ON knowledge (project_id, source, chunk_index);")
                
            print("✅ Memory: Ready (V2 Architecture).")
        except Exception as e:
            print(f"❌ Memory Error: {e}")

    async def stop(self):
        if self.pool: await self.pool.close()

    async def _embed(self, text):
        if not self.model: return None
        vector = await asyncio.to_thread(self.model.encode, text)
        return vector.tolist()

    # --- PROJECT MANAGEMENT ---

    async def create_or_update_project(self, name: str, structure: Dict) -> int:
        if not self.pool: return -1
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow("""
                INSERT INTO projects (name, file_structure)
                VALUES ($1, $2)
                ON CONFLICT (name) 
                DO UPDATE SET 
                    file_structure = $2, 
                    updated_at = CURRENT_TIMESTAMP
                RETURNING id
            """, name, json.dumps(structure))
            return row['id']

    async def list_projects(self) -> List[str]:
        if not self.pool: return []
        async with self.pool.acquire() as conn:
            rows = await conn.fetch("SELECT name FROM projects ORDER BY updated_at DESC")
            return [r['name'] for r in rows]

    async def get_project_details(self, project_name: str) -> str:
        # (Same as before)
        if not self.pool: return "DB Error"
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow("SELECT file_structure, updated_at FROM projects WHERE name = $1", project_name)
            if not row: return f"Project '{project_name}' not found."
            
            structure = json.loads(row['file_structure'])
            date_str = row['updated_at'].strftime("%Y-%m-%d %H:%M")
            tree_text = f"--- PROJECT: {project_name} (Last Updated: {date_str}) ---\n"
            
            def render_tree(node, depth=0):
                text = ""
                prefix = "  " * depth + "├─ "
                for key, val in node.items():
                    if val == "__FILE__":
                        text += f"{prefix}{key}\n"
                    else:
                        text += f"{prefix}{key}/\n"
                        text += render_tree(val, depth + 1)
                return text

            tree_text += render_tree(structure)
            return tree_text

    # --- V2 INGESTION (Atomic & Smart) ---

    async def ingest_file_smart(self, project_id: int, source: str, text: str):
        """
        The V2 Ingestion Engine:
        1. Recursive Splitting (Context Safe)
        2. Dynamic Overlap Calculation (Precision)
        3. Atomic Transaction (Anti-Ghosting)
        """
        if not self.model or not self.pool: return

        # 1. Recursive Splitting
        # We target ~1000 chars. The overlap is handled naturally by the structure
        # or can be forced. For now, we trust the semantic splitter.
        raw_chunks = recursive_split_text(text, chunk_size=1000)
        
        if not raw_chunks: return

        # 2. Vectorization (Batch CPU)
        vectors = await asyncio.to_thread(self.model.encode, raw_chunks)
        vectors_list = vectors.tolist()

        batch_data = []
        for i, chunk in enumerate(raw_chunks):
            # 3. Dynamic Overlap Measurement
            overlap_int = 0
            if i > 0:
                overlap_int = calculate_overlap(raw_chunks[i-1], chunk)
            
            # (project_id, content, source, embedding, chunk_index, overlap_size)
            batch_data.append((project_id, chunk, source, vectors_list[i], i, overlap_int))

        # 4. ATOMIC TRANSACTION
        async with self.pool.acquire() as conn:
            async with conn.transaction():
                # A. Wipe stale data
                await conn.execute(
                    "DELETE FROM knowledge WHERE project_id = $1 AND source = $2", 
                    project_id, source
                )
                
                # B. Insert fresh chunks
                await conn.executemany(
                    """INSERT INTO knowledge 
                       (project_id, content, source, embedding, chunk_index, overlap_size) 
                       VALUES ($1, $2, $3, $4, $5, $6)""",
                    batch_data
                )

    # Legacy wrapper for compatibility (if needed)
    async def save_knowledge_batch(self, project_id: int, items: List[dict]):
        # We redirect to the smart ingester per file.
        # Note: This is inefficient if called with mixed files, but fine for migration.
        # Ideally, routes.py calls ingest_file_smart directly.
        pass 

    async def save_interaction(self, user_msg, ai_msg):
        text = f"User: {user_msg}\nAI: {ai_msg}"
        vector = await self._embed(text)
        if vector and self.pool:
            async with self.pool.acquire() as conn:
                await conn.execute(
                    "INSERT INTO memories (content, embedding) VALUES ($1, $2)",
                    text, vector
                )

    # --- V2 RETRIEVAL (Paged & Stitched) ---

    async def get_file_content(self, filename: str, page: int = 1, page_size: int = 5) -> Dict:
        """
        Retrieves a seamless 'page' of text, stitched perfectly.
        """
        if not self.pool: return {"content": "", "has_more": False}
        clean_name = filename.split("/")[-1] 
        offset = (page - 1) * page_size
        
        # 1. Fetch Ordered Page
        query = """
            SELECT content, chunk_index, overlap_size, count(*) OVER() as total_chunks
            FROM knowledge 
            WHERE source ILIKE $1 
            ORDER BY chunk_index ASC
            LIMIT $2 OFFSET $3
        """
        
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(query, f"%{clean_name}", page_size, offset)
        
        if not rows: return {"content": "", "has_more": False, "total_chunks": 0}

        full_text = ""
        for row in rows:
            # 2. Deterministic Stitching
            # Index 0 is the ONLY chunk that we don't strip.
            if row['chunk_index'] == 0:
                full_text += row['content']
            else:
                cut = row['overlap_size']
                full_text += row['content'][cut:]
                
        total_chunks = rows[0]['total_chunks']
        has_more = (offset + len(rows)) < total_chunks
        
        return {
            "content": full_text, 
            "page": page, 
            "has_more": has_more,
            "total_chunks": total_chunks
        }

    async def search_scoped(self, query: str, project_name: str = None, limit=5, exclude_paths: List[str] = None):
        if not self.pool: return []
        results = []
        seen_content = set()
        
        if exclude_paths is None: exclude_paths = []

        async with self.pool.acquire() as conn:
            project_id = None
            if project_name and project_name != "all":
                pid_row = await conn.fetchrow("SELECT id FROM projects WHERE name = $1", project_name)
                if pid_row: project_id = pid_row['id']
            
            if self.model:
                vector = await self._embed(query)
                
                sql = """
                    SELECT content, source, ingested_at, (embedding <-> $1) as dist 
                    FROM knowledge 
                    WHERE 1=1
                """
                args = [vector]
                arg_counter = 2
                
                if project_id:
                    sql += f" AND project_id = ${arg_counter}"
                    args.append(project_id)
                    arg_counter += 1
                
                if exclude_paths:
                    sql += f" AND source != ALL(${arg_counter})"
                    args.append(exclude_paths)
                    arg_counter += 1
                    
                sql += f" ORDER BY dist LIMIT ${arg_counter}"
                args.append(limit)

                know_rows = await conn.fetch(sql, *args)
                
                for r in know_rows:
                    if r['content'] not in seen_content:
                        date_val = r['ingested_at']
                        date_str = date_val.strftime("%Y-%m-%d") if date_val else "N/A"
                        snippet = r['content'][:300].replace('\n', ' ') + "..."
                        results.append(f"[REL | {r['source']} | {date_str}]: {snippet}")
                        seen_content.add(r['content'])

        return results

memory_service = MemoryService()