# src/services/execution/runner.py
import asyncio
import websockets
import json
import subprocess
from pathlib import Path

# Constants
WSL_PORT = 8765
SERVER_SCRIPT_NAME = "server_script.py"

class WSLExecutionService:
    def __init__(self):
        self.ip = "localhost"
        self.uri = None
        self._server_process = None

    def _get_wsl_ip(self) -> str:
        """Finds the internal IP of the WSL instance."""
        try:
            result = subprocess.run(
                ["wsl", "-d", "Debian", "hostname", "-I"], 
                capture_output=True, text=True
            )
            return result.stdout.strip().split(" ")[0]
        except:
            return "localhost"

    async def _ensure_server_running(self):
        """Launches the python server inside WSL if not already running."""
        self.ip = self._get_wsl_ip()
        self.uri = f"ws://{self.ip}:{WSL_PORT}"

        # 1. Check if already alive
        try:
            async with websockets.connect(self.uri, open_timeout=0.2):
                return
        except:
            pass # Not running, let's start it.

        # 2. Prepare the command
        # We assume the server script is in the same folder mapped to /mnt/c/...
        current_dir = Path(__file__).parent
        script_path_win = current_dir / SERVER_SCRIPT_NAME
        
        # Convert C:\Path to /mnt/c/Path
        drive = script_path_win.drive.lower().replace(":", "")
        rel = str(script_path_win).replace(script_path_win.drive, "").replace("\\", "/")
        wsl_path = f"/mnt/{drive}{rel}"

        print(f"🚀 Execution: Launching WSL Server at {wsl_path}...")
        
        # 3. Fire and Forget (Non-blocking)
        self._server_process = subprocess.Popen(
            ["wsl", "-d", "Debian", "python3", wsl_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        # 4. Wait for spin-up
        for _ in range(10):
            await asyncio.sleep(0.5)
            try:
                async with websockets.connect(self.uri, open_timeout=0.2):
                    print("✅ Execution: WSL Connected.")
                    return
            except:
                continue
        
        print("❌ Execution: WSL failed to start.")

    async def run_code(self, code: str):
        """Generator that streams stdout from WSL."""
        await self._ensure_server_running()
        
        try:
            async with websockets.connect(self.uri) as ws:
                # Send the code payload
                await ws.send(json.dumps({"code": code}))

                async for msg in ws:
                    data = json.loads(msg)
                    msg_type = data.get("type")

                    if msg_type == "stream":
                        yield data.get("content", "")
                    elif msg_type == "status" and data.get("status") in ["finished", "error"]:
                        break
        except Exception as e:
            yield f"\n[System Error: {e}]"

# Singleton
execution_service = WSLExecutionService()