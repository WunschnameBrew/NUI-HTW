# src/services/execution/server_script.py
import asyncio
import websockets
import json
import traceback
import sys
from contextlib import redirect_stdout, redirect_stderr
from concurrent.futures import ThreadPoolExecutor

HOST = "0.0.0.0"
PORT = 8765

executor = ThreadPoolExecutor(max_workers=1)

# --- THE FIX: GLOBAL PERSISTENT STATE ---
# Now variables defined in Step 1 will exist in Step 10.
GLOBAL_REPL_SCOPE = {} 

class AsyncStream:
    def __init__(self, queue, stream_name):
        self.queue = queue
        self.name = stream_name
    def write(self, msg):
        if msg: self.queue.put_nowait((self.name, msg))
    def flush(self): pass

async def handler(websocket):
    queue = asyncio.Queue()

    async def sender_task():
        while True:
            stream, content = await queue.get()
            if stream is None: break 
            try:
                await websocket.send(json.dumps({"type": "stream", "stream": stream, "content": content}))
            except: break
            queue.task_done()

    sender = asyncio.create_task(sender_task())

    try:
        async for message in websocket:
            data = json.loads(message)
            code = data.get("code", "")
            
            # Reset command (Optional: if you ever want to clear memory)
            if code.strip() == "%reset":
                GLOBAL_REPL_SCOPE.clear()
                await websocket.send(json.dumps({"type": "status", "status": "finished"}))
                continue

            await websocket.send(json.dumps({"type": "status", "status": "running"}))
            
            loop = asyncio.get_running_loop()
            
            def run_sync():
                stream_out = AsyncStream(queue, "stdout")
                stream_err = AsyncStream(queue, "stderr")
                try:
                    with redirect_stdout(stream_out), redirect_stderr(stream_err):
                        # Use the GLOBAL scope
                        exec(code, GLOBAL_REPL_SCOPE)
                except Exception:
                    tb = traceback.format_exc()
                    queue.put_nowait(("error", tb))

            await loop.run_in_executor(executor, run_sync)
            
            await queue.put((None, None))
            await sender
            await websocket.send(json.dumps({"type": "status", "status": "finished"}))

    except Exception:
        pass
    finally:
        if not sender.done(): sender.cancel()

async def main():
    print(f"🚀 WSL Executor running on ws://{HOST}:{PORT} (Stateful Mode)")
    async with websockets.serve(handler, HOST, PORT):
        await asyncio.Future()

if __name__ == "__main__":
    asyncio.run(main())